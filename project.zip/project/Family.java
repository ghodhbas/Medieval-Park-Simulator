
/**
 * calss representing the family group
 */
public class Family extends Group
{

    public Family(){
        super();    
        //add two royals
        addPerson(25);
        addPerson(25);
    }
        
}
