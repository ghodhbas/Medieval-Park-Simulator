
/**
 *class representing the individual group
 */
public class Individual extends Group
{
    /**
     * Constructor for objects of class Individual
     */
    public Individual( int rank)
    {super();
     addPerson(rank);
    }

    
}
