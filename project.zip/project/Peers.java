
/**
 * class representing the peer group
 */
public class Peers extends Group
{

    /**
     * Constructor for objects of class Peers
     */
    public Peers()
    { super();
    }

   
}
