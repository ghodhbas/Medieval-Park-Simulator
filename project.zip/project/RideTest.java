

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class RideTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class RideTest
{
    /**
     * Default constructor for test class RideTest
     */
    public RideTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
    
    /** tests constructor */
    @Test
    public void testConstructor(){
        
    }
    
    /** tests adding to ride */
    @Test
    public void testAddToRide(){
    }
    
    /** testsadding to queue */
    @Test
    public void testADDToQueue(){
        
    }
    
    /** tests dequeueing from queue */
    @Test
    public void testDequeue(){
        
    }
    
    /** tests discharging groups from ride */
    @Test
    public void testDischargeGroups(){
        
    }
    
    
}
